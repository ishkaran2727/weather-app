package com.example.clima20;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Activity2 extends AppCompatActivity {

    TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        resultTextView = (TextView) findViewById(R.id.resultTextView);

        Intent intent = getIntent();
        String message = intent.getStringExtra(MainActivity.CITY_NAME);
        resultTextView.setText(message);

    }
}


